# WordSearchPuzzle
Created a word-search puzzle using Python and the pyta library. This is an interactive text-based game, allowing the users to play word-search and find the given words from a text file.
